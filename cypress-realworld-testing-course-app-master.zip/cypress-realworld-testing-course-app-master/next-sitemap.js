module.exports = {
  siteUrl: 'https://cypress-realworld-testing-course-app.vercel.app/',
  generateRobotsTxt: true,
}